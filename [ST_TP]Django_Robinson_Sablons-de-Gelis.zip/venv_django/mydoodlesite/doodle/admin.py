from django.contrib import admin
from doodle.models import Room
from doodle.models import Meeting
from doodle.models import DateChoice

# Register your models here.
admin.site.register(Room)
admin.site.register(Meeting)
admin.site.register(DateChoice)
