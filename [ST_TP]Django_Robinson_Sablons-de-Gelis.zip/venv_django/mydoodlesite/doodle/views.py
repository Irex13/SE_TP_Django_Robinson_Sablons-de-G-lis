from django.shortcuts import render, get_object_or_404, HttpResponseRedirect, HttpResponse, reverse
from django.http import HttpResponse
from django.template import RequestContext, loader
from .models import Meeting, DateChoice, Room



def index(request):
    return HttpResponse("Premier testttt")

def meetings(request):
    meetings = Meeting.objects.all()
    template = loader.get_template('doodle/meetings.html')
    context = {
        'meetings': meetings,
    }
    return HttpResponse(template.render(context, request))

def details(request, meeting_id):
    details = Meeting.objects.get(id=meeting_id)
    dates = DateChoice.objects.filter(meeting=meeting_id)
    rooms = Room.objects.all()
    template = loader.get_template('doodle/details.html')
    context = {
        'details':details,
        'dates':dates,
        'rooms':rooms,
    }
    return HttpResponse(template.render(context, request))

def voteDate(request, meeting_id):
    p = get_object_or_404(Meeting, pk=meeting_id)
    dates = DateChoice.objects.filter(meeting=meeting_id)
    rooms = Room.objects.all()
    try:
        selecteded_date = p.datechoice_set.get(pk=request.POST['dateChoice'])
    except (KeyError, DateChoice.DoesNotExist):
        return render(request, 'doodle/details.html',{
            'details' : p,
            'dates':dates,
            'rooms':rooms,
            'error_message': "You did'nt select a date."
        })
    else:
        selecteded_date.nbVote += 1
        selecteded_date.save()
        if selecteded_date.nbVote >= p.nb_votes_req:
            p.date_chosen = selecteded_date.date
            p.save()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
        return HttpResponseRedirect(reverse('doodle:resultDate', args=(p.id,)))

def resultDate(request, meeting_id):
    details = Meeting.objects.get(id=meeting_id)
    dates = DateChoice.objects.filter(meeting=meeting_id)
    rooms = Room.objects.all()
    template = loader.get_template('doodle/result.html')
    context = {
        'details':details,
        'dates':dates,
        'rooms':rooms,
    }
    return HttpResponse(template.render(context, request))

def selectRoom(request, meeting_id):
    p = get_object_or_404(Meeting, pk=meeting_id)
    dates = DateChoice.objects.filter(meeting=meeting_id)
    rooms = Room.objects.all()
    try:
        selecteded_room = Room.objects.get(pk=request.POST['roomChoice'])
    except (KeyError, Room.DoesNotExist):
        return render(request, 'doodle/details.html',{
            'details' : p,
            'dates':dates,
            'rooms':rooms,
            'error_message': "You did'nt select a room."
        })
    else:
        p.room  = selecteded_room
        p.save()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        return HttpResponseRedirect(reverse('doodle:details', args=(p.id,)))



