from django.contrib import admin
from django.urls import path
from doodle import views

app_name = 'doodle'
urlpatterns = [
    path('',views.index, name='index'),
    path('meetings',views.meetings, name='meetings'),
    path('meetings/<int:meeting_id>/', views.details, name='details'),
    path('meetings/<int:meeting_id>/voteDate', views.voteDate, name='voteDate'),
    path('meetings/<int:meeting_id>/resultDate', views.resultDate, name='resultDate'),
    path('meetings/<int:meeting_id>/selectRoom', views.selectRoom, name='selectRoom')
]