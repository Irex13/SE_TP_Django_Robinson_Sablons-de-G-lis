from django.apps import AppConfig


class DoodleConfig(AppConfig):
    name = 'doodle'
