from django.db import models

# Create your models here.
class Room(models.Model):
    name = models.CharField(max_length=50)
    location = models.CharField(max_length=50)
class Meeting(models.Model):
    name = models.CharField(max_length=50)
    room = models.ForeignKey(Room, on_delete=models.CASCADE, null=True, blank=True)
    nb_votes_req = models.IntegerField('nb_votes_req')
    date_chosen = models.DateTimeField(blank=True, null=True)
class DateChoice(models.Model):
    meeting = models.ForeignKey(Meeting, on_delete = models.CASCADE)
    date = models.DateTimeField('date choice')
    nbVote = models.IntegerField(default=0)

